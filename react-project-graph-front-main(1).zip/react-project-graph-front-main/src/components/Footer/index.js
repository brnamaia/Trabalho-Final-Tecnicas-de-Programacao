import React from 'react';
import './style.css'

export function Footer() {
    return(
      <div className="footer">
        <p>Todos os direitos reservados © 2021 Isabel, Bruna, Matheus, Guilherme, Mykaeull</p>
      </div>
    )
}
