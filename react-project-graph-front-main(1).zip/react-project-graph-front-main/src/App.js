import React from 'react';
import Router from './routes';

const App = () => <Router />;

export default App;
