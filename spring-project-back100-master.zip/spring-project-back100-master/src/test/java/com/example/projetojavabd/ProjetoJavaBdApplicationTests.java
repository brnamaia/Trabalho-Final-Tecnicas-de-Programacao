package com.example.projetojavabd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJavaBdApplicationTests {

    @Test
    void contextLoads() {
    }

}
